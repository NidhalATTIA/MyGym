#include <gtk/gtk.h>
void coor(char nom[],char nom1[] ,char age[],char age1[],char domaine[],char domaine1[],char tel[],char tel1[],char exp[],char exp1[],char forma[],char forma1[]);
