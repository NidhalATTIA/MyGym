#include <gtk/gtk.h>
void sup_dispo(char Num[30]);
