#include <gtk/gtk.h>
typedef struct
{
char nom_med [30];
char age_med[30];
char domaine_med[30];
char tel_med[30];
char exp_med[30];
char forma_med[30];
}med;
void cmed(med m);

