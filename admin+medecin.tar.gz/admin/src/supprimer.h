void sup_speci(char num[30]);

