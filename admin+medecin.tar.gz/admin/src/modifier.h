void modifi(char Nom[30],char age[30],char poids[30],char probleme_med[30],char taille[30],char allergie[30],char sang[30],char traitement[30],char note[30],char num[30]);
