void saisir(char Username [20], char Password [20] ,int role);
